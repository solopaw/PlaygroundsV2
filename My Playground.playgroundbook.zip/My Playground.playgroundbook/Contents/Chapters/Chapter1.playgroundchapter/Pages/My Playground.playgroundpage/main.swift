import PlaygroundSupport
PlaygroundPage.current.setLiveView(ContentView())
