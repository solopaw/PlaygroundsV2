import SwiftUI

struct XCalendar: View {
    @State var selection = 0
    var body: some View {
        RestrauntView()
    }
}
public struct ContentView:View {
    public var body: some View{
        XCalendar()
    }
    public init(){}
}


struct MenuView:View {
    var body: some View{
        ScrollView{
            Text("Food List")
        }
    }
}

struct Row:View {
    var item:Item
    var body: some View{
        HStack{
            Image(item.name)
            Spacer()
            VStack{
                Text(item.name)
                Text(item.description)
            }
        }
    }
}


struct Item:Identifiable,Codable {
    var name:String
    var id: String = UUID().uuidString
    var description:String
}

struct Restaurant: Identifiable {
    let id = UUID()
    let name: String
}

// A view that shows the data for one Restaurant.
struct RestaurantRow: View {
    var restaurant: Restaurant
    
    var body: some View {
        Text("Come and eat at \(restaurant.name)")
    }
}

// Create three restaurants, then show them in a list.
struct RestrauntView: View {
    let restaurants = [
        Restaurant(name: "Joe's Original"),
        Restaurant(name: "The Real Joe's Original"),
        Restaurant(name: "Original Joe's")
    ]
    
    var body: some View {
        List(restaurants) { restaurant in
            RestaurantRow(restaurant: restaurant)
        }
    }
}

